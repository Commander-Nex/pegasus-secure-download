Put the .bat file on your desctop open and enjoy :) 

I tried to make it as easy as possible :)